df0 <- input1 %>% filter(Id != 2)
df1 <- df0 %>% group_by(From)
df2 <- df1 %>% count
