df0 <- input1 %>% filter(From != "GVA")
df1 <- df0 %>% group_by(To)
df2 <- df1 %>% summarize(n = median(Id))
